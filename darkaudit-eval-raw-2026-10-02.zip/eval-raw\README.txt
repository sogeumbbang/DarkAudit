DarkAudit 평가 측정 원본 (2026-10-02). 수치 해석은 저장소 docs/eval-results.md 참고. 비밀값(.env) 없음.
current_eval_dir : 마지막 상태의 docs/eval (hybrid/run-N = DA-15 개선 후 구조 입력 3회, hybrid_visual/run-N = 텍스트 근거 보정 후 스크린샷 3회, 각 hybrid_report*.json)
prev_runs        : hybrid_visual_before_text_grounding(보정 전 스크린샷 3회), hybrid_after_prompt1(DA-15 프롬프트 변경 직후 구조 입력 3회), hybrid_dep5(dep-001 5회) 등
prev_fixed       : 평가 스크립트 결함 수정 직후(gpt-5.6-luna) 구조 입력 3회와 리포트
baseline_reports : 결함 수정 전 gpt-5.6-luna / gpt-6-luna 리포트
hybrid_6luna_runs: gpt-6-luna 구조 입력 3회 예측
raw, raw_dep     : 모델 원본 응답(DA-03·DA-15 choice_pairs/price_comparisons)
diag             : DA-07·DA-12 위치 실패 진단용 모델 finding과 OCR 줄
logs             : 호출 수·비용 로그와 실행 로그
